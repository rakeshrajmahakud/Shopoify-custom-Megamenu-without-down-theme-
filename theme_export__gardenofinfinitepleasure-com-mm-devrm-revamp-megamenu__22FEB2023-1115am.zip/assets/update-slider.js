(function () {
	document.addEventListener('shopify:section:load', function (e) {
		$('.product__media-sublist').slick(getSubSliderProductSettings());
		$('.product__media-list').slick(getSliderSettings());
	});
})();
