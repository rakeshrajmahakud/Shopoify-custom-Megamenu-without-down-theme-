// class CartRemoveButton extends HTMLElement {
// 	constructor() {
// 	  super();
// 	  this.addEventListener('click', (event) => {
// 		event.preventDefault();
// 		this.closest('cart-notification').updateQuantity(this.dataset.index, 0);
// 	  });
// 	}
// }

// customElements.define('cart-remove-button', CartRemoveButton);

class CartNotification extends HTMLElement {
	constructor() {
		super();

		this.notification = document.getElementById('cart-notification');
		this.header = document.querySelector('sticky-header');
		// this.onBodyClick = this.handleBodyClick.bind(this);

		this.notification.addEventListener('keyup', (evt) => evt.code === 'Escape' && this.close());
		this.querySelectorAll('.cart-notification__close').forEach((closeButton) =>
			closeButton.addEventListener('click', this.close.bind(this))
		);
		document.querySelectorAll('.cs-site-overlay').forEach((closeOverlay) =>
			closeOverlay.addEventListener('click', this.close.bind(this))
		);
	}

	open() {
		this.notification.classList.add('active');
		document.body.classList.add('cart-notification-active');

		this.notification.addEventListener('transitionend', () => {
			this.notification.focus();
			trapFocus(this.notification);
		}, {once: true});

		document.body.addEventListener('click', this.onBodyClick);
	}

	close() {
		this.notification.classList.remove('active');
		document.body.classList.remove('cart-notification-active');

		document.body.removeEventListener('click', this.onBodyClick);

		removeTrapFocus(this.activeElement);
	}

	renderContents(parsedState) {
		this.productId = parsedState.id;
		this.getSectionsToRender().forEach((section => {
			document.getElementById(section.id).innerHTML =
				this.getSectionInnerHTML(parsedState.sections[section.id], section.selector);
		}));
		this.open();
	}


	getSectionsToRender() {
		return [
			{
				id: 'cart-notification-product',
			},
			{
				id: 'cart-notification-button'
			},
			{
				id: 'cart-icon-bubble'
			}
		];
	}

	getSectionInnerHTML(html, selector = '.shopify-section') {
		return new DOMParser()
			.parseFromString(html, 'text/html')
			.querySelector(selector).innerHTML;
	}

	// handleBodyClick(evt) {
	// 	const target = evt.target;
	// 	if (target !== this.notification && !target.closest('cart-notification')) {
	// 		this.close();
	// 	}
	// }

	setActiveElement(element) {
		this.activeElement = element;
	}

	updateQuantity(line, quantity, name) {
		this.enableLoading(line);

		const body = JSON.stringify({
			line,
			quantity,
			sections: this.getSectionsToRender().map((section) => section.section),
			sections_url: window.location.pathname
		});

		fetch(`${routes.cart_change_url}`, {...fetchConfig(), ...{body}})
			.then((response) => {
				return response.text();
			})
			.then((state) => {
				const parsedState = JSON.parse(state);
				this.classList.toggle('is-empty', parsedState.item_count === 0);

				this.getSectionsToRender().forEach((section => {
					const elementToReplace =
						document.getElementById(section.id).querySelector(section.selector) || document.getElementById(section.id);

					elementToReplace.innerHTML =
						this.getSectionInnerHTML(parsedState.sections[section.section], section.selector);
				}));

				this.updateLiveRegions(line, parsedState.item_count);
				document.getElementById(`cart-notification-product-${line}`)?.querySelector(`[name="${name}"]`)?.focus();
				this.querySelectorAll('.loading-overlay').forEach((overlay) => overlay.classList.add('hidden'));
			}).catch(() => {
			this.querySelectorAll('.loading-overlay').forEach((overlay) => overlay.classList.add('hidden'));
			document.getElementById('cart-errors').textContent = window.cartStrings.error;
			// this.disableLoading();
		});
	}

	enableLoading(line) {
		this.querySelectorAll('.loading-overlay')[line - 1].classList.remove('hidden');
		document.activeElement.blur();
	}


}

let cartLink = document.querySelector('.header__cart');

function notificationOpen(e) {
	document.body.classList.add('cart-notification-active');
	e.preventDefault();
}

if (cartLink) {
	cartLink.addEventListener('click', notificationOpen);
}


customElements.define('cart-notification', CartNotification);


/**
 * Currency Helpers
 * -----------------------------------------------------------------------------
 * A collection of useful functions that help with currency formatting
 *
 * Current contents
 * - formatMoney - Takes an amount in cents and returns it as a formatted dollar value.
 *
 */

const moneyFormat = '${{amount}}';

/**
 * Format money values based on your shop currency settings
 * @param  {Number|string} cents - value in cents or dollar amount e.g. 300 cents
 * or 3.00 dollars
 * @param  {String} format - shop money_format setting
 * @return {String} value - formatted value
 */
function formatMoney(cents, format) {
	if (typeof cents === 'string') {
		cents = cents.replace('.', '');
	}
	let value = '';
	const placeholderRegex = /\{\{\s*(\w+)\s*\}\}/;
	const formatString = theme.moneyFormat || moneyFormat;

	function formatWithDelimiters(
		number,
		precision = 2,
		thousands = ',',
		decimal = '.'
	) {
		if (isNaN(number) || number == null) {
			return 0;
		}

		number = (number / 100.0).toFixed(precision);

		const parts = number.split('.');
		const dollarsAmount = parts[0].replace(
			/(\d)(?=(\d\d\d)+(?!\d))/g,
			`$1${thousands}`
		);
		const centsAmount = parts[1] ? decimal + parts[1] : '';

		return dollarsAmount + centsAmount;
	}

	switch (formatString.match(placeholderRegex)[1]) {
		case 'amount':
			value = formatWithDelimiters(cents, 2);
			break;
		case 'amount_no_decimals':
			value = formatWithDelimiters(cents, 0);
			break;
		case 'amount_with_comma_separator':
			value = formatWithDelimiters(cents, 2, '.', ',');
			break;
		case 'amount_no_decimals_with_comma_separator':
			value = formatWithDelimiters(cents, 0, '.', ',');
			break;
	}

	return formatString.replace(placeholderRegex, value);
}


/**
 * Adds a Shopify size attribute to a URL
 *
 * @param src
 * @param size
 * @returns {*}
 */

function getSizedImageUrl(src, size) {
	if (size === null) {
		return src;
	}

	if (size === 'master') {
		return removeProtocol(src);
	}

	var match = src.match(/\.(jpg|jpeg|gif|png|bmp|bitmap|tiff|tif)(\?v=\d+)?$/i);

	if (match) {
		var prefix = src.split(match[0]);
		var suffix = match[0];
		return removeProtocol(prefix[0] + '_' + size + suffix);
	} else {
		return null;
	}
}

function removeProtocol(path) {
	return path.replace(/http(s)?:/, '');
}


let updateCartCount = function (count) {
	if (count) {
		$(".cart-count-bubble span").text(count);
	} else {
		$(".cart-count-bubble").remove();
	}
}

let updateCartSubtotal = function (subtotal) {
	let subtotalWrapper = $(".cart-notification__bottom");
	let subtotalTotal = $(".cart-notification__subtotal .totals");
	let subtotalValue = $(".cart-notification__subtotal .totals__subtotal-value");

	if (subtotal) {
		subtotalWrapper.addClass('active');
		if (subtotalValue.length > 0) {
			subtotalValue.text(
				`${formatMoney(subtotal, Shopify.money_format)}`
			)
		} else {
			subtotalTotal.append(`<p class="totals__subtotal-value">${formatMoney(subtotal, Shopify.money_format)}</p>`)
		}

	} else {
		subtotalWrapper.removeClass('active');
		subtotalValue.remove();
	}
}

let updateCartNotifications = function (data) {
	if (data.item_count > 0) {
		$(".cart-notification-product").html("");
		for (let i = 0; i < data.item_count; i++) {
			let optons = ``;
			data.items[i].options_with_values.forEach(element => {
				optons += `<div class="cart-notification-product__option">
					<dt>${element.name}:</dt>
					<dd>${element.value}</dd>
				</div>`;
			});

			// let image = data.items[i].image;

			const imgSrc = data.items[i].featured_image ? data.items[i].featured_image.url : data.items[i].image;
			const imgAlt = data.items[i].featured_image ? data.items[i].featured_image.alt : '';
			const imgUrl = imgSrc && getSizedImageUrl(imgSrc, '140x');
			// const image = r(imgSrc, `<img class="image__img lazyload" alt="${imgAlt}" data-src="${imgUrl}" />`);

			$(".cart-notification-product").append(`
			<div id="cart-notification-product-${i + 1}" class="cart-notification-product__inner">
				<div class="cart-notification-product__inner-top">
					<img class="cart-notification-product__image" src="${imgUrl}" alt="${imgAlt}" width="70" height="auto" loading="lazy">
					<div class="cart-notification-product__info">
						<div class="cart-notification-product__name">${data.items[i].product_title}</div>
						<dl class="cart-notification-product__options">
							${optons}
						</dl>
						<div class="cart-notification-product__footer">
							<span class="cart-notification-product__footer-price">${formatMoney(data.items[i].final_price, Shopify.money_format)}</span>
							<div class="cart-notification__total-prrice">
								<div class="loading-overlay hidden">
									<div class="loading-overlay__spinner">
										<svg aria-hidden="true" focusable="false" role="presentation" class="spinner" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
											<circle class="path" fill="none" stroke-width="6" cx="33" cy="33" r="30"></circle>
										</svg>
									</div>
								</div>
								<div class="cart-item__price-wrapper medium-up">
									<span class="price">${formatMoney(data.items[i].final_line_price, Shopify.money_format)}</span>
								</div>
							</div>
						</div>
					</div>	
				</div>
				<div class="cart-notification-product__inner-bottom">
					<div class="cart-notification-product__quantity">
						<quantity-input class="quantity">
							<button class="quantity__button no-js-hidden" name="minus" type="button">
								<span class="visually-hidden">Decrease quantity for Jewelry five</span>
									<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" role="presentation" class="icon icon-minus" fill="none" viewBox="0 0 13 3">
									<path d="M12.1193 0.990918L5.99341 0.993329L0.547412 0.990918V1.67559L5.99341 1.67318L12.1193 1.67559V0.990918Z" fill="currentColor" stroke="currentColor"></path>
									</svg>
	
							</button>
							<input class="quantity__input" type="number" name="updates[]" value="${data.items[i].quantity}" min="0" aria-label="Quantity for Jewelry five" id="Quantity-${i + 1}" data-index="${i + 1}">
							<button class="quantity__button no-js-hidden" name="plus" type="button">
								<span class="visually-hidden">Increase quantity for Jewelry five</span>
								<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" role="presentation" class="icon icon-plus" fill="none" viewBox="0 0 13 13">
								<path d="M6.67326 5.99333L12.1193 5.99092V6.67559L6.67326 6.67318L6.67567 12.1192L5.991 12.1192L5.99341 6.67318L0.547412 6.67559V5.99092L5.99341 5.99333L5.991 0.547327L6.67567 0.547327L6.67326 5.99333Z" fill="currentColor" stroke="currentColor"></path>
								</svg>
							</button>
						</quantity-input>
					</div>
					<div class="cart-notification-product__remove">
						<cart-remove-button id="Remove-${i + 1}" data-index="${i + 1}">
							<a href="/cart/change?id=${data.items[i].key}&amp;quantity=0" aria-label="Remove ${data.items[i].title}">
								<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" fill="none" viewBox="0 0 11 11">
									<path d="M9.00568 0.823302L5.33333 4.4989L1.66099 0.823302L1.48421 0.646368L1.30736 0.823223L0.823223 1.30736L0.646368 1.48421L0.823302 1.66099L4.4989 5.33333L0.823302 9.00568L0.646368 9.18246L0.823223 9.35931L1.30736 9.84344L1.48421 10.0203L1.66099 9.84337L5.33333 6.16777L9.00568 9.84337L9.18246 10.0203L9.35931 9.84344L9.84344 9.35931L10.0203 9.18246L9.84337 9.00568L6.16777 5.33333L9.84337 1.66099L10.0203 1.48421L9.84344 1.30736L9.35931 0.823223L9.18246 0.646368L9.00568 0.823302Z" fill="currentColor" stroke="currentColor" stroke-width="0.5"/>
								</svg>
		
								Remove
							</a>
						</cart-remove-button>
					</div>
				</div>
			</div>
			`);
		}

	} else {
		$(".cart-notification-product").html(`
			<p class="cart-notification-empty">${window.cartStrings.empty}</p>
		`);
	}

}
$(document).on('click', ".cart-notification-product__remove a", function (e) {
	e.preventDefault();


	let line = $(this).parent().attr("data-index");
	let quantity = $(this).parents(".cart-notification-product__info").find(".quantity__input").val();
	let query = {
		'line': line,
		'quantity': 0
	};


	$.ajax({
		url: window.Shopify.routes.root + 'cart/change.js',
		type: "POST",
		data: query,
		dataType: 'json',
		success: function (data) {
			updateCartSubtotal(data.items_subtotal_price);
			updateCartCount(data.item_count);
			updateCartNotifications(data);
		}
	});
});

$(document).on('change', ".quantity__input", function (e) {
	e.preventDefault();


	let line = $(this).attr("data-index");
	let quantity = $(this).val();
	let query = {
		'line': line,
		'quantity': quantity
	};


	$.ajax({
		url: window.Shopify.routes.root + 'cart/change.js',
		type: "POST",
		data: query,
		dataType: 'json',
		success: function (data) {
			updateCartSubtotal(data.items_subtotal_price);
			updateCartCount(data.item_count);
			updateCartNotifications(data);
		}
	});
});


$(document).on('product-form-responsed', function (event, response) {

	$.ajax({
		url: window.Shopify.routes.root + 'cart.js',
		type: "POST",
		dataType: 'json',
		success: function (data) {
			updateCartSubtotal(data.items_subtotal_price);
		}
	});

});